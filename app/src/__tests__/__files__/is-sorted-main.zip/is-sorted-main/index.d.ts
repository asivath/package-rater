declare function checksort<T = any> (array: T[], comparator?: (a: T, b: T) => number)

export = checksort
